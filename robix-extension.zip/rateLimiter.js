// ============================================================================
// Centralized Rate Limiter for Roblox API
// Loaded into the service worker via ES module import
// ============================================================================

export const PRIORITY = {
    TRANSACTION: 10,
    CATALOG: 5,
    USER: 3,
    THUMBNAIL: 2,
    LOW: 1
}

const DOMAIN_BUDGETS = {
    'economy.roblox.com': 45,
    'catalog.roblox.com': 20,
    'thumbnails.roblox.com': 45,
    'users.roblox.com': 30,
    'groups.roblox.com': 30,
    '_default': 30
}

const MAX_CONCURRENCY = 3
const MAX_RETRIES = 5
const WINDOW_MS = 60 * 1000 // 1 minute sliding window
const DEFAULT_429_PAUSE_MS = 60 * 1000
const MAX_429_RETRIES = 10
const MAX_FAILED_REQUESTS = 500

export class RateLimiter {
    constructor() {
        // Per-domain sliding window timestamps
        this.domainTimestamps = {}
        // Per-domain pause until timestamp (for 429s)
        this.domainPauseUntil = {}
        // Priority queue of pending requests
        this.queue = []
        // Currently in-flight count
        this.activeCount = 0
        // CSRF token cache
        this.csrfTokens = {}
        // Stats
        this.stats = {
            totalRequests: 0,
            total429s: 0,
            totalRetries: 0,
            byDomain: {}
        }
    }

    _getDomain(url) {
        try {
            return new URL(url).hostname
        } catch {
            return '_default'
        }
    }

    _getBudget(domain) {
        return DOMAIN_BUDGETS[domain] || DOMAIN_BUDGETS['_default']
    }

    _pruneTimestamps(domain) {
        const now = Date.now()
        if (!this.domainTimestamps[domain]) {
            this.domainTimestamps[domain] = []
            return
        }
        this.domainTimestamps[domain] = this.domainTimestamps[domain].filter(
            ts => now - ts < WINDOW_MS
        )
    }

    _getWaitTime(domain) {
        this._pruneTimestamps(domain)
        const budget = this._getBudget(domain)
        const timestamps = this.domainTimestamps[domain] || []

        if (timestamps.length < budget) return 0

        // Wait until the oldest entry expires
        const oldest = timestamps[0]
        return (oldest + WINDOW_MS) - Date.now()
    }

    _getDomainPauseWait(domain) {
        const pauseUntil = this.domainPauseUntil[domain] || 0
        const wait = pauseUntil - Date.now()
        return wait > 0 ? wait : 0
    }

    _recordRequest(domain) {
        if (!this.domainTimestamps[domain]) {
            this.domainTimestamps[domain] = []
        }
        this.domainTimestamps[domain].push(Date.now())

        // Stats
        if (!this.stats.byDomain[domain]) {
            this.stats.byDomain[domain] = { requests: 0, rate429s: 0, retries: 0 }
        }
        this.stats.byDomain[domain].requests++
        this.stats.totalRequests++
    }

    _pauseDomain(domain, durationMs) {
        this.domainPauseUntil[domain] = Date.now() + durationMs
        console.log(`[RateLimiter] Domain ${domain} paused for ${Math.round(durationMs / 1000)}s`)
    }

    async _storeFailedRequest(entry) {
        try {
            const { failedRequests = [] } = await chrome.storage.local.get('failedRequests')
            failedRequests.push(entry)
            const overflow = failedRequests.length > MAX_FAILED_REQUESTS
            const trimmed = failedRequests.slice(-MAX_FAILED_REQUESTS)
            await chrome.storage.local.set({ failedRequests: trimmed })
            if (overflow) {
                console.warn(`[RateLimiter] Failed requests cap reached (${MAX_FAILED_REQUESTS}). Oldest failures are being dropped. Some data may need to be re-synced.`)
                await chrome.storage.local.set({ failedRequestsOverflow: true })
            }
        } catch (e) {
            console.warn('[RateLimiter] Failed to store failed request:', e)
        }
    }

    async retryFailedRequests() {
        try {
            const { failedRequests = [] } = await chrome.storage.local.get('failedRequests')
            if (failedRequests.length === 0) return { retried: 0, succeeded: 0 }

            console.log(`[RateLimiter] Retrying ${failedRequests.length} previously failed requests`)
            const remaining = []
            let succeeded = 0

            for (const entry of failedRequests) {
                try {
                    await this.enqueue(entry.url, { method: entry.method || 'GET' }, entry.priority || PRIORITY.LOW)
                    succeeded++
                } catch {
                    remaining.push(entry)
                }
            }

            await chrome.storage.local.set({ failedRequests: remaining })
            if (remaining.length === 0) {
                await chrome.storage.local.remove('failedRequestsOverflow')
            }
            console.log(`[RateLimiter] Retry results: ${succeeded} succeeded, ${remaining.length} still failing`)
            return { retried: failedRequests.length, succeeded }
        } catch (e) {
            console.warn('[RateLimiter] Failed to retry failed requests:', e)
            return { retried: 0, succeeded: 0 }
        }
    }

    async persistState() {
        try {
            const activePauses = {}
            for (const [domain, until] of Object.entries(this.domainPauseUntil)) {
                if (until > Date.now()) activePauses[domain] = until
            }
            // Only persist domain pauses — queue items can't be meaningfully restored
            if (Object.keys(activePauses).length > 0) {
                await chrome.storage.local.set({
                    rateLimiterState: { domainPauses: activePauses, timestamp: Date.now() }
                })
            } else {
                await chrome.storage.local.remove('rateLimiterState')
            }
        } catch (e) {
            console.warn('[RateLimiter] Failed to persist state:', e)
        }
    }

    async restoreState() {
        try {
            const { rateLimiterState } = await chrome.storage.local.get('rateLimiterState')
            if (!rateLimiterState) return false

            // Always clear persisted state — we don't re-enqueue dead requests
            await chrome.storage.local.remove('rateLimiterState')

            // Only restore domain pauses (still relevant after SW restart)
            if (rateLimiterState.domainPauses) {
                for (const [domain, until] of Object.entries(rateLimiterState.domainPauses)) {
                    if (until > Date.now()) this.domainPauseUntil[domain] = until
                }
            }

            // Log what we're NOT restoring
            const droppedCount = (rateLimiterState.queue || []).length
            if (droppedCount > 0) {
                console.log(`[RateLimiter] Dropped ${droppedCount} orphaned requests from previous session (callers are gone)`)
            }

            return false // No requests restored
        } catch (e) {
            console.warn('[RateLimiter] Failed to restore state:', e)
            return false
        }
    }

    /**
     * Enqueue a request through the rate limiter.
     * @param {string} url
     * @param {object} options - fetch options (method, headers, body, etc.)
     * @param {number} priority - Higher = more important
     * @returns {Promise<{status, ok, body, headers}>}
     */
    enqueue(url, options = {}, priority = PRIORITY.LOW) {
        return new Promise((resolve, reject) => {
            this.queue.push({
                url,
                options,
                priority,
                resolve,
                reject,
                retries: 0,
                csrfRetried: false,
                rateLimitRetries: 0
            })
            this._sortQueue()
            this._drain()
        })
    }

    _sortQueue() {
        this.queue.sort((a, b) => b.priority - a.priority)
    }

    async _drain() {
        // Process as many queued items as concurrency allows
        while (this.activeCount < MAX_CONCURRENCY && this.queue.length > 0) {
            // Find the first item whose domain is not paused and not rate-limited
            let picked = null
            let pickedIndex = -1

            for (let i = 0; i < this.queue.length; i++) {
                const item = this.queue[i]
                const domain = this._getDomain(item.url)

                const pauseWait = this._getDomainPauseWait(domain)
                if (pauseWait > 0) {
                    // Schedule a drain after the pause expires
                    this._scheduleDrain(pauseWait)
                    continue
                }

                const rateWait = this._getWaitTime(domain)
                if (rateWait > 0) {
                    // Schedule a drain after the rate window opens
                    this._scheduleDrain(rateWait)
                    continue
                }

                picked = item
                pickedIndex = i
                break
            }

            if (!picked) break

            // Remove from queue
            this.queue.splice(pickedIndex, 1)
            this.activeCount++

            // Execute asynchronously
            this._execute(picked).finally(() => {
                this.activeCount--
                this._drain()
            })
        }
    }

    _drainTimerId = null

    _scheduleDrain(delayMs) {
        // Avoid scheduling multiple timers; use the shortest delay
        if (this._drainTimerId) return
        this._drainTimerId = setTimeout(() => {
            this._drainTimerId = null
            this._drain()
        }, Math.max(delayMs, 50))
    }

    async _execute(item) {
        const { url, options, resolve, reject } = item
        const domain = this._getDomain(url)
        const method = (options.method || 'GET').toUpperCase()

        // Record this request in the sliding window
        this._recordRequest(domain)

        // Attach CSRF token for mutating requests
        const fetchOptions = { ...options, credentials: 'include' }
        if (['POST', 'PATCH', 'DELETE'].includes(method) && this.csrfTokens[domain]) {
            fetchOptions.headers = { ...fetchOptions.headers, 'X-CSRF-TOKEN': this.csrfTokens[domain] }
        }

        try {
            console.log(`[RateLimiter] ${method} ${url} (p=${item.priority}, q=${this.queue.length}, active=${this.activeCount})`)
            const controller = new AbortController()
            const timeoutId = setTimeout(() => controller.abort(), 30000)
            let response
            try {
                response = await fetch(url, { ...fetchOptions, signal: controller.signal })
            } finally {
                clearTimeout(timeoutId)
            }

            // --- CSRF handling (403) ---
            if (response.status === 403 && !item.csrfRetried) {
                let newToken = null
                for (const [key, value] of response.headers.entries()) {
                    if (key.toLowerCase() === 'x-csrf-token') {
                        newToken = value
                        break
                    }
                }

                if (newToken) {
                    console.log(`[RateLimiter] CSRF token refresh for ${url}`)
                    this.csrfTokens[domain] = newToken
                    item.csrfRetried = true
                    // Re-enqueue at front (high priority retry)
                    this.queue.unshift(item)
                    this._sortQueue()
                    return // activeCount will be decremented in .finally, _drain will re-process
                }
            }

            // --- 429 handling ---
            if (response.status === 429) {
                this.stats.total429s++
                if (this.stats.byDomain[domain]) {
                    this.stats.byDomain[domain].rate429s++
                }

                // Parse Retry-After header
                let retryAfterMs = DEFAULT_429_PAUSE_MS
                const retryAfterHeader = response.headers.get('Retry-After')
                if (retryAfterHeader) {
                    const seconds = parseInt(retryAfterHeader, 10)
                    if (!isNaN(seconds)) {
                        retryAfterMs = seconds * 1000
                    }
                }

                if (retryAfterMs > 25000) {
                    this.persistState()  // fire-and-forget
                }

                item.rateLimitRetries++

                if (item.rateLimitRetries >= MAX_429_RETRIES) {
                    console.error(`[RateLimiter] Exhausted 429 retries (${MAX_429_RETRIES}) for ${url}`)
                    this._storeFailedRequest({
                        url,
                        method: options.method || 'GET',
                        priority: item.priority,
                        timestamp: Date.now(),
                        error: `Rate limited ${MAX_429_RETRIES} times`
                    })
                    reject(new Error(`Request rate-limited after ${MAX_429_RETRIES} retries: ${url}`))
                    return
                }

                // Progressive backoff: multiply base pause by attempt number, cap at 4x
                const progressivePause = retryAfterMs * Math.min(item.rateLimitRetries + 1, 4)
                this._pauseDomain(domain, progressivePause)
                this.queue.unshift(item)
                this._sortQueue()
                if (progressivePause > 25000) {
                    // Use alarm for long pauses (survives SW kill)
                    const alarmName = `rateLimiter-resume-${domain}`
                    chrome.alarms.create(alarmName, { delayInMinutes: progressivePause / 60000 })
                } else {
                    this._scheduleDrain(progressivePause)
                }
                return
            }

            // --- 401/403 (after CSRF retry) — reject immediately ---
            if (response.status === 401 || (response.status === 403 && item.csrfRetried)) {
                const body = await this._readBody(response)
                resolve({ status: response.status, ok: false, body, headers: this._serializeHeaders(response.headers) })
                return
            }

            // --- 5xx / server errors ---
            if (response.status >= 500) {
                throw new Error(`Server error: ${response.status}`)
            }

            // --- Success or client error (4xx except 401/403/429) ---
            const body = await this._readBody(response)
            resolve({
                status: response.status,
                ok: response.ok,
                body,
                headers: this._serializeHeaders(response.headers)
            })

        } catch (error) {
            // Detect timeout abort specifically
            if (error.name === 'AbortError') {
                console.warn(`[RateLimiter] Request timed out after 30s: ${url}`)
            }
            // Network error, timeout, or 5xx thrown above
            item.retries++
            this.stats.totalRetries++
            if (this.stats.byDomain[domain]) {
                this.stats.byDomain[domain].retries++
            }

            if (item.retries <= MAX_RETRIES) {
                // Exponential backoff: 2s, 4s, 8s, 16s, 32s
                const backoffMs = Math.pow(2, item.retries) * 1000
                console.warn(`[RateLimiter] Retry ${item.retries}/${MAX_RETRIES} for ${url} in ${backoffMs}ms: ${error.message}`)

                setTimeout(() => {
                    this.queue.unshift(item)
                    this._sortQueue()
                    this._drain()
                }, backoffMs)
            } else {
                console.error(`[RateLimiter] Exhausted retries for ${url}: ${error.message}`)
                // Store failed request
                this._storeFailedRequest({
                    url,
                    method: options.method || 'GET',
                    priority: item.priority,
                    timestamp: Date.now(),
                    error: error.message
                })
                reject(new Error(`Request failed after ${MAX_RETRIES} retries: ${error.message}`))
            }
        }
    }

    async _readBody(response) {
        try {
            return await response.json()
        } catch {
            try {
                return await response.text()
            } catch {
                return null
            }
        }
    }

    _serializeHeaders(headers) {
        const obj = {}
        if (headers && typeof headers.entries === 'function') {
            for (const [key, value] of headers.entries()) {
                obj[key] = value
            }
        }
        return obj
    }

    getStats() {
        return {
            ...this.stats,
            queueLength: this.queue.length,
            activeCount: this.activeCount,
            domainPauses: Object.entries(this.domainPauseUntil)
                .filter(([, until]) => until > Date.now())
                .map(([domain, until]) => ({ domain, remainingMs: until - Date.now() }))
        }
    }

    isActive() {
        if (this.activeCount > 0 || this.queue.length > 0) return true
        // Also active if any domain is paused (requests will resume after pause)
        return Object.values(this.domainPauseUntil).some(until => until > Date.now())
    }
}

// Singleton created by background.js on import
