// Global configuration loaded by background.js via ES module import
export const config = {
    SUPABASE_FN_BASE: 'https://ljzrbkwyzlbrghtohdfl.supabase.co/functions/v1'
};
